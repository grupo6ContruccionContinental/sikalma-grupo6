<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Personal - SIKALMA</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <%@ include file="navbar.jsp" %>
    <main>
        <div class="encabezado">
            <div class="encabezado-texto">
                <h1>Gestión de Personal Médico</h1>
                <p>Visualice y administre la información de los doctores registrados</p>
            </div>
            <a href="/doctor/nuevo" class="btn-primario">+ Registrar Doctor</a>
        </div>

        <div class="buscador-seccion" style="margin: 20px 0; background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <form action="/doctor/buscar" method="get" style="display: flex; gap: 10px; align-items: center;">
                <input type="text" name="dni" placeholder="Ingrese DNI del doctor..."
                       style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; width: 300px;" required>
                <button type="submit" class="btn-primario">Buscar por DNI</button>
                <a href="/doctor/gestion" class="btn-secundario" style="text-decoration: none;">Limpiar</a>
            </form>
        </div>

        <div class="tabla-contenedor">
            <table class="tabla-gestion">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>DNI</th>
                        <th>Edad</th>
                        <th>Especialidad</th>
                        <th>Teléfono</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach var="doc" items="${doctores}">
                        <tr>
                            <td>#D${doc.id}</td>
                            <td>${doc.nombre}</td>
                            <td>${doc.dni}</td>
                            <td>${doc.getEdad()}</td>
                            <td>${doc.especialidad}</td>
                            <td>${doc.telefono}</td>
                            <td class="acciones-celda">
                                <a href="/doctor/editar?id=${doc.id}" class="btn-editar">Editar</a>
                                <a href="/doctor/advertir?id=${doc.id}" class="btn-eliminar">Eliminar</a>
                            </td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>