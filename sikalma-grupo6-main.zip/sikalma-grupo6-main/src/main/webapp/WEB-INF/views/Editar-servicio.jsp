<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/images/logo-policlinico.png">
    <title>Editar Servicio - SIKALMA</title>
    <link rel="stylesheet" href="/css/admin.css">
</head>
<body>
<%@ include file="navbar.jsp" %>

<main>
    <div class="encabezado">
        <div class="encabezado-texto">
            <div class="retorno">
                <a href="/servicio/gestion">Servicios</a>
                <span>›</span>
                <span>Editar Servicio #S0${servicio.id}</span>
            </div>
            <h1>Editar Servicio</h1>
            <p>Modifica el nombre, descripción o costo del servicio</p>
        </div>
    </div>

    <div class="formulario-card">

        <c:if test="${not empty error}">
                <div style="display: flex; align-items: center; gap: 12px; background-color: #FFFFFF; color: #842029; padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; border-left: 5px solid #dc3545; box-shadow: 0 2px 12px rgba(0,0,0,0.06); font-size: 0.95rem;">
                    <span style="color: #dc3545; font-size: 1.1rem; font-weight: bold;">⚠️</span>
                    <span style="font-weight: 500;">${error}</span>
                </div>
            </c:if>

        <h2>Datos del Servicio — ID: #S0${servicio.id}</h2>

        <form action="/servicio/editar" method="post">

            <input type="hidden" name="id" value="${servicio.id}">

            <div class="campo">
                <label>Nombre del servicio</label>
                <input type="text" value="${servicio.nombre}" name="nombre" required>
            </div>

            <div class="campo">
                <label>Descripción</label>
                <textarea rows="3" name="descripcion" required>${servicio.descripcion}</textarea>
            </div>

            <div class="campo">
                <label>Costo (S/)</label>
                <input type="number" value="${servicio.costo}" name="costo" step="0.01" min="0" required>
            </div>

            <div class="form-acciones">
                <a href="/servicio/gestion" class="btn-secundario">Cancelar</a>
                <button type="submit" class="btn-primario">Guardar Cambios</button>
            </div>
        </form>
    </div>
</main>
</body>
</html>



.