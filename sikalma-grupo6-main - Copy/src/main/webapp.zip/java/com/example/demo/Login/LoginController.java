package com.example.demo.Login;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
public class LoginController {

    private final LoginService loginService;

    public LoginController(LoginService loginService) {
        this.loginService = loginService;
    }

    // ─── Raíz ────────────────────────────────────────────────────────────────
    @GetMapping("/")
    public String raiz(HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u != null) return redirigirSegunRol(u);
        return "redirect:/login";
    }

    // ─── GET /login ───────────────────────────────────────────────────────────
    @GetMapping("/login")
    public String mostrarLogin(HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u != null) return redirigirSegunRol(u);
        return "Login";
    }

    // ─── POST /login ──────────────────────────────────────────────────────────
    @PostMapping("/login")
    public String procesarLogin(@RequestParam String correo,
                                @RequestParam String contrasena,
                                HttpServletRequest request,
                                Model model) {

        Optional<Usuario> resultado = loginService.autenticar(correo, contrasena);

        if (resultado.isEmpty()) {
            model.addAttribute("error", "Correo o contraseña incorrectos");
            model.addAttribute("correo", correo);
            return "Login";
        }

        Usuario usuario = resultado.get();

        // Invalidar sesión anterior para evitar session fixation
        HttpSession vieja = request.getSession(false);
        if (vieja != null) vieja.invalidate();

        // Crear sesión nueva limpia
        HttpSession nueva = request.getSession(true);
        nueva.setAttribute("usuarioLogueado", usuario);
        nueva.setAttribute("rolUsuario", usuario.getRol().name());
        nueva.setAttribute("nombreUsuario", usuario.getNombre());

        return redirigirSegunRol(usuario);
    }

    // ─── GET /logout ──────────────────────────────────────────────────────────
    @GetMapping("/logout")
    public String cerrarSesion(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // ─── GET /acceso-denegado ─────────────────────────────────────────────────
    @GetMapping("/acceso-denegado")
    public String accesoDenegado(HttpSession session, Model model) {
        Usuario u = (Usuario) session.getAttribute("usuarioLogueado");
        if (u != null) {
            model.addAttribute("urlRetorno", u.getRol() == Usuario.Rol.ADMIN
                    ? "/metricas/g-metricas" : "/cita/g-citas");
        }
        return "Acceso-denegado";
    }

    // ─── Util ─────────────────────────────────────────────────────────────────
    private String redirigirSegunRol(Usuario usuario) {
        return usuario.getRol() == Usuario.Rol.ADMIN
                ? "redirect:/metricas/g-metricas"
                : "redirect:/cita/g-citas";
    }
}
