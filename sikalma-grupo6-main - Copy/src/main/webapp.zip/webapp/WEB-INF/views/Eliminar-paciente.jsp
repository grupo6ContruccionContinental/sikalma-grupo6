<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/images/logo-policlinico.png">
    <title>Eliminar Paciente - SIKALMA</title>
    <link rel="stylesheet" href="/css/admin.css">
    <link rel="stylesheet" href="/css/eliminar.css">
</head>
<body class="modal-eliminar">
    <div class="modal-card">
        <div class="icono-alerta">⚠️</div>
        <h2>¿Eliminar este paciente?</h2>
        <p>
            Estás a punto de eliminar el registro de <strong>${paciente.nombres}</strong>
            (DNI: ${paciente.dni}). Si existen citas o atenciones asociadas, podrían verse afectadas.
            <br><br>
            Esta acción no puede deshacerse.
        </p>
        <div class="modal-acciones">
            <a href="/paciente/gestion" class="btn-secundario">Volver</a>
            <a href="/paciente/eliminar?id=${paciente.id}" class="btn-danger">Sí, eliminar</a>
        </div>
    </div>
</body>
</html>
