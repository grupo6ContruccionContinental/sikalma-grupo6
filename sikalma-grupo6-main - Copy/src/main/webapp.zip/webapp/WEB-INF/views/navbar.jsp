<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<section class="menu">
    <div class="menu-img">
        <img src="/images/logo-policlinico.png" alt="logo del policlinico">
    </div>
    <ul>
        <%-- Métricas: visible para ambos roles --%>
        <li><a href="/metricas/g-metricas" class="${paginaActiva == 'metricas' ? 'activo' : ''}">Métricas</a></li>

        <%-- Gestión de Citas: visible para ambos roles --%>
        <li><a href="/cita/g-citas" class="${paginaActiva == 'citas' ? 'activo' : ''}">Gestión de Citas</a></li>

        <%-- Registrar Cita: solo ADMIN --%>
        <c:if test="${sessionScope.rolUsuario == 'ADMIN'}">
            <li><a href="/cita/r-citas" class="${paginaActiva == 'r-citas' ? 'activo' : ''}">Registrar Cita</a></li>
        </c:if>

        <%-- Gestión Atenciones: solo DOCTOR --%>
        <c:if test="${sessionScope.rolUsuario == 'DOCTOR'}">
            <li><a href="/atencion/gestion" class="${paginaActiva == 'atencion' ? 'activo' : ''}">Gestión de Atenciones</a></li>
        </c:if>

        <%-- Servicios, Pacientes, Personal: solo ADMIN --%>
        <c:if test="${sessionScope.rolUsuario == 'ADMIN'}">
            <li><a href="/servicio/gestion" class="${paginaActiva == 'servicios' ? 'activo' : ''}">Servicios</a></li>
            <li><a href="/paciente/gestion" class="${paginaActiva == 'paciente' ? 'activo' : ''}">Pacientes</a></li>
            <li><a href="/doctor/gestion"   class="${paginaActiva == 'personal' ? 'activo' : ''}">Personal</a></li>
        </c:if>
    </ul>

    <%-- Sesión activa --%>
    <div class="menu-sesion">
        <span class="menu-usuario">
            <c:out value="${sessionScope.nombreUsuario}" default="Usuario"/>
            <small>(<c:out value="${sessionScope.rolUsuario}"/>)</small>
        </span>
        <a href="/logout" class="btn-logout">Cerrar sesión</a>
    </div>
</section>
